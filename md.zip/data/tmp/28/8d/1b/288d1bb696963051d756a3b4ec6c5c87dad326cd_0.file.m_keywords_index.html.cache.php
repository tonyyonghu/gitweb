<?php
/* Smarty version 3.1.33, created on 2019-06-06 08:14:19
  from 'D:\phpStudy\PHPTutorial\WWW\md\view\m_keywords_index.html' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_5cf8cb5b05cd88_69582491',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '288d1bb696963051d756a3b4ec6c5c87dad326cd' => 
    array (
      0 => 'D:\\phpStudy\\PHPTutorial\\WWW\\md\\view\\m_keywords_index.html',
      1 => 1559808620,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5cf8cb5b05cd88_69582491 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_checkPlugins(array(0=>array('file'=>'D:\\phpStudy\\PHPTutorial\\WWW\\md\\includes\\smarty\\plugins\\modifier.date_format.php','function'=>'smarty_modifier_date_format',),1=>array('file'=>'D:\\phpStudy\\PHPTutorial\\WWW\\md\\includes\\smarty\\plugins\\function.math.php','function'=>'smarty_function_math',),));
$_smarty_tpl->compiled->nocache_hash = '4569182095cf8cb5b01ffb0_80535697';
?>
<!DOCTYPE HTML>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	 <meta name="renderer" content="webkit">

	<title><?php echo $_smarty_tpl->tpl_vars['suiji_keywords']->value;?>
</title>
	<meta name="keywords" content="<?php echo $_smarty_tpl->tpl_vars['suiji_keywords']->value;?>
" />
	<meta name="description" content="<?php echo $_smarty_tpl->tpl_vars['suiji_keywords']->value;?>
,<?php echo $_smarty_tpl->tpl_vars['description']->value;?>
" />
	<meta http-equiv="Cache-Control" content="no-transform" />
	<meta http-equiv="Cache-Control" content="no-siteapp" />
	<link rel="stylesheet" href="/view/css/sm.min.css">
	<link rel="stylesheet" href="/view/css/my_style.css">
	<link rel="Shortcut icon" href="/view/images/favicon.ico" />
	<?php echo '<script'; ?>
 src='/view/js/zepto.min.js'><?php echo '</script'; ?>
>
	<?php echo '<script'; ?>
 src='/view/js/sm.min.js'><?php echo '</script'; ?>
>
	<?php echo '<script'; ?>
 src="/view/js/swiper.min.js"><?php echo '</script'; ?>
>
	<?php echo '<script'; ?>
 src="/view/js/jquery-1.4.2.min.js"><?php echo '</script'; ?>
>

</head>
<body class="theme-1">

	<div class="fixediv leftadv">
		<a href="http://www.7nbmkp.top/"><img src="/view/images/3.gif" width="140" height="186" alt="性感美女" /></a>
		<a class="close" href="javascript:void(0);">关闭广告</a>
	</div>

	<div class="fixediv rightadv">
		<a href="http://www.7nbmkp.top/"><img src="/view/images/11.gif" width="140" height="186" alt="清纯美女" /></a>
		<a class="close" href="javascript:void(0);">关闭广告</a>
	</div>

<div class="page-group">
		<div class="panel-overlay"></div>
	<!-- 左侧边栏 -->
	<div class="panel panel-left panel-reveal" id="panel-left-demo">
		<div class="content">
			<div class="list-block">
				<ul>
					<li class="item-content news-title no-arrow">
					<div class="item-inner">
						<div class="item-title-row">
							<div class="item-title"><b>栏目分类</b></div>
						</div>
					</div>
					</li>
					<li>
						<a href="/"  class="item-content item-link external">
							<div class="item-inner">
								<div class="item-title">首 页</div>
							</div>
						</a>
					</li>
					<li class='hover'>
					<a href='/list_1_<?php echo call_user_func_array( $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['myfunc'][0], array( array('con'=>"生物世界"),$_smarty_tpl ) );?>
.html' class='item-content item-link external' ><div class='item-inner'><div class='item-title'>生物世界</div></div></a></li>
					<li>
						<a href='/list_2_<?php echo call_user_func_array( $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['myfunc'][0], array( array('con'=>"美女背影"),$_smarty_tpl ) );?>
.html'  class="item-content item-link external">
							<div class="item-inner">
								<div class="item-title">美女背影</div>
							</div>
						</a>
					</li>
					<li>
						<a href='/list_3_<?php echo call_user_func_array( $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['myfunc'][0], array( array('con'=>"金融货币"),$_smarty_tpl ) );?>
.html'  class="item-content item-link external">
							<div class="item-inner">
								<div class="item-title">金融货币</div>
							</div>
						</a>
					</li>
					<li>
						<a href='/list_4_<?php echo call_user_func_array( $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['myfunc'][0], array( array('con'=>"科学研究"),$_smarty_tpl ) );?>
.html'  class="item-content item-link external">
							<div class="item-inner">
								<div class="item-title">科学研究</div>
							</div>
						</a>
					</li>
					<li>
						<a href='/list_5_<?php echo call_user_func_array( $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['myfunc'][0], array( array('con'=>"生活百科"),$_smarty_tpl ) );?>
.html'  class="item-content item-link external">
							<div class="item-inner">
								<div class="item-title">生活百科</div>
							</div>
						</a>
					</li>
					<li>
						<a href='/list_6_<?php echo call_user_func_array( $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['myfunc'][0], array( array('con'=>"移门图案"),$_smarty_tpl ) );?>
.html'  class="item-content item-link external">
							<div class="item-inner">
								<div class="item-title">移门图案</div>
							</div>
						</a>
					</li>
					<li>
						<a href='/list_7_<?php echo call_user_func_array( $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['myfunc'][0], array( array('con'=>"清纯美女"),$_smarty_tpl ) );?>
.html'  class="item-content item-link external">
							<div class="item-inner">
								<div class="item-title">清纯美女</div>
							</div>
						</a>
					</li>
					<li>
						<a href='/list_8_<?php echo call_user_func_array( $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['myfunc'][0], array( array('con'=>"职业人物"),$_smarty_tpl ) );?>
.html'  class="item-content item-link external">
							<div class="item-inner">
								<div class="item-title">职业人物</div>
							</div>
						</a>
					</li>
					<li>
						<a href='/list_9_<?php echo call_user_func_array( $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['myfunc'][0], array( array('con'=>"韩文模板"),$_smarty_tpl ) );?>
.html'  class="item-content item-link external">
							<div class="item-inner">
								<div class="item-title">韩文模板</div>
							</div>
						</a>
					</li>
					<li>
						<a href='/list_10_<?php echo call_user_func_array( $_smarty_tpl->smarty->registered_plugins[Smarty::PLUGIN_FUNCTION]['myfunc'][0], array( array('con'=>"背景底纹"),$_smarty_tpl ) );?>
.html'  class="item-content item-link external">
							<div class="item-inner">
								<div class="item-title">背景底纹</div>
							</div>
						</a>
					</li>
				</ul>
			</div>
		</div>
	</div>
	<!-- 右侧边栏 -->
	
	<div class="page page-current" id="router">
		<header class="bar bar-nav">
			<span class="icon icon-menu pull-left open-panel" data-panel="#panel-left-demo"></span>
			<h2 class="title title2"><?php echo $_smarty_tpl->tpl_vars['suiji_keywords']->value;?>
</h2>
		</header>
		
		<div class="content">
			<div class="list-block news-list">
				<ul>
					<li>
						<a href="#" class="item-link item-content news-title">
							<div class="item-inner">
								<div class="item-title"><b>推荐图文</b></div>
								<div class="item-after"></div>
							</div>
						</a>
					</li>
					<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['linksView']->value, 'v');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['v']->value) {
?>
					<li>
						<a href="<?php echo $_smarty_tpl->tpl_vars['v']->value['link'];?>
" class="item-link item-content no-arrow">
							<div class="item-inner">
								<div class="item-title"><?php echo $_smarty_tpl->tpl_vars['v']->value['name'];?>
</div>
								<div class="item-after"><?php echo smarty_modifier_date_format(time(),"%d-%m");?>
</div>
							</div>
						</a>
					</li>
			<?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
				
				
				
				
					<li>
						<a href="#" class="item-link item-content news-title">
							<div class="item-inner">
								<div class="item-title"><b>搜索<span style='color:green;'><?php echo $_smarty_tpl->tpl_vars['keywords']->value[9];?>
</span>的人还搜索了</b></div>
								<div class="item-after"></div>
							</div>
						</a>
					</li>
					<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['keywordsRandInfo']->value, 'v');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['v']->value) {
?>
			<li>
						<a href="/list_<?php echo smarty_function_math(array('equation'=>rand(1,100)),$_smarty_tpl);?>
.html" class="item-link item-content no-arrow">
							<div class="item-inner">
								<div class="item-title"><?php echo $_smarty_tpl->tpl_vars['v']->value['keyword'];?>
</div>
								<div class="item-after"><?php echo smarty_modifier_date_format(time(),"%d-%m");?>
</div>
							</div>
						</a>
			</li>
			<?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
				</ul>
			</div>
			
			<div class="list-block news-list">
			
			<ul>
				
			<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['keywordsListLinks']->value, 'v');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['v']->value) {
?>
			<li>
				<a href="<?php echo $_smarty_tpl->tpl_vars['v']->value['link'];?>
" class="item-link item-content no-arrow">
					<div class="item-inner">
						<div class="item-title"><?php echo $_smarty_tpl->tpl_vars['v']->value['name'];?>
</div>
						<div class="item-after"><?php echo smarty_modifier_date_format(time(),"%d-%m");?>
</div>
					</div>
				</a>
			</li>
			<?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
			
			
			<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['keywordsRandIndexLinks1']->value, 'v');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['v']->value) {
?>
			<li>
						<a href="<?php echo $_smarty_tpl->tpl_vars['v']->value['link'];?>
" class="item-link item-content no-arrow">
							<div class="item-inner">
								<div class="item-title"><?php echo $_smarty_tpl->tpl_vars['v']->value['name'];?>
</div>
								<div class="item-after"><?php echo smarty_modifier_date_format(time(),"%d-%m");?>
</div>
							</div>
						</a>
			</li>
			<?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
			
			
			<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['keywordsRandIndexLinks2']->value, 'v');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['v']->value) {
?>
			<li>
						<a href="<?php echo $_smarty_tpl->tpl_vars['v']->value['link'];?>
" class="item-link item-content no-arrow">
							<div class="item-inner">
								<div class="item-title"><?php echo $_smarty_tpl->tpl_vars['v']->value['name'];?>
</div>
								<div class="item-after"><?php echo smarty_modifier_date_format(time(),"%d-%m");?>
</div>
							</div>
						</a>
			</li>
			<?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
			
			
			<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['keywordsRandInfo3Links']->value, 'v');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['v']->value) {
?>
			<li>
						<a href="<?php echo $_smarty_tpl->tpl_vars['v']->value['link'];?>
" class="item-link item-content no-arrow">
							<div class="item-inner">
								<div class="item-title"><?php echo $_smarty_tpl->tpl_vars['v']->value['name'];?>
</div>
								<div class="item-after"><?php echo smarty_modifier_date_format(time(),"%d-%m");?>
</div>
							</div>
						</a>
			</li>
			<?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
			</ul>
			</div>
			
			<footer class="content-block-title center">
	<p><a href="<?php echo $_smarty_tpl->tpl_vars['siteIndex']->value['mdomain'];?>
" class="gray">手机版</a><span class="pipe">|</span><a href="<?php echo $_smarty_tpl->tpl_vars['siteIndex']->value['domain'];?>
" class="gray">电脑版</a></p>
	<p>&copy;2017 <?php echo $_smarty_tpl->tpl_vars['suiji_keywords']->value;?>
 <?php echo $_smarty_tpl->tpl_vars['siteIndex']->value['domain'];?>
, All rights reserved.</p>
	<div style="display:none;"><?php echo '<script'; ?>
 type="text/javascript" src="https://s23.cnzz.com/z_stat.php?id=1274739193&web_id=1274739193"><?php echo '</script'; ?>
></div>
	
</footer>
		</div>
	</div>
	
</div>


<?php echo '<script'; ?>
 type="text/javascript">
$(document).ready(function(){

	$(".fixediv a").click(function(){
		
		$(".fixediv").fadeOut(400);
		
	});
	
	$(".fixediv").floatadv();
	
});

jQuery.fn.floatadv = function(loaded) {
	var obj = this;
	body_height = parseInt($(window).height());
	block_height = parseInt(obj.height());
	
	top_position = parseInt((body_height/2) - (block_height/2) + $(window).scrollTop());
	if (body_height<block_height) { top_position = 0 + $(window).scrollTop(); };
	
	if(!loaded) {
		obj.css({'position': 'absolute'});
		obj.css({ 'top': top_position });
		$(window).bind('resize', function() { 
			obj.floatadv(!loaded);
		});
		$(window).bind('scroll', function() { 
			obj.floatadv(!loaded);
		});
	} else {
		obj.stop();
		obj.css({'position': 'absolute'});
		obj.animate({ 'top': top_position }, 400, 'linear');
	}
}
<?php echo '</script'; ?>
>

	
	
</body>
</html><?php }
}
