<?php

// 网站的配置文件


$_cfg = array();
$_cfg['host'] = 'localhost';
$_cfg['user'] = 'root';
$_cfg['pwd'] = 'root';
$_cfg['db'] = 'com162722';
$_cfg['char'] = 'utf8';
$_cfg['debug'] = true;






